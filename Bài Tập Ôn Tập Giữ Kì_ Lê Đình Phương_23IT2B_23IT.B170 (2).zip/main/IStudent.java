package main;

interface IStudent {
    void Display();
}
